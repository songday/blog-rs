export function userLanguage() {
    return navigator.language;
}